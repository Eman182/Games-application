from backend_layer.models.guest import Guest

x = Guest()
print(isinstance(x, Guest))

