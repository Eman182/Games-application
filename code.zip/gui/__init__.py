# player global variable

player_global = None
